import {Job} from './job';

export const JOBS: Job[] = [
  {
    "user": "apadma338@gmail.com",
    "jobs": 1228,
    "chars": 38.96
  },
  {
    "user": "akhilareddy6543@gmail.com",
    "jobs": 1128,
    "chars": 32.65
  },
  {
    "user": "sushmasabbani1532@gmail.com",
    "jobs": 1019,
    "chars": 38.17
  },
  {
    "user": "ramyaaleti1357@gmail.com",
    "jobs": 998,
    "chars": 27.64
  },
  {
    "user": "ramya15798@gmail.com",
    "jobs": 970,
    "chars": 26.75
  },
  {
    "user": "navaneethakandlapelli@gmail.com",
    "jobs": 879,
    "chars": 48.04
  },
  {
    "user": "anusriianureddy@gmail.com",
    "jobs": 871,
    "chars": 26.19
  },
  {
    "user": "haalswolv@gmail.com",
    "jobs": 856,
    "chars": 83.63
  },
  {
    "user": "adepujyothsna1999@gmail.com",
    "jobs": 743,
    "chars": 36.43
  },
  {
    "user": "d.tejashwini@gmail.com",
    "jobs": 616,
    "chars": 40.79
  },
  {
    "user": "ashokbayya531@gmail.com",
    "jobs": 615,
    "chars": 28.91
  },
  {
    "user": "alekhyanamani1559@gmail.com",
    "jobs": 526,
    "chars": 54.91
  },
  {
    "user": "yagrawal.ya@gmail.com",
    "jobs": 433,
    "chars": 77.71
  },
  {
    "user": "meenamahankali2020@gmail.com",
    "jobs": 379,
    "chars": 13.03
  },
  {
    "user": "jalasai1cse@gmail.com",
    "jobs": 275,
    "chars": 20.25
  },
  {
    "user": "advait.raykar@gmail.com",
    "jobs": 207,
    "chars": 71.7
  },
  {
    "user": "vantaryrevanthkumar@gmail.com",
    "jobs": 203,
    "chars": 18.43
  },
  {
    "user": "bbt1203@gmail.com",
    "jobs": 202,
    "chars": 109.83
  },
  {
    "user": "pakshara97@gmail.com",
    "jobs": 186,
    "chars": 26.79
  },
  {
    "user": "purna.saiakash@gmail.com",
    "jobs": 136,
    "chars": 22.67
  },
  {
    "user": "trivenireddy09@gmail.com",
    "jobs": 133,
    "chars": 8.606
  },
  {
    "user": "gurpreetsarngal@gmail.com",
    "jobs": 132,
    "chars": 69.95
  },
  {
    "user": "jayant99acharya@gmail.com",
    "jobs": 119,
    "chars": 19.63
  },
  {
    "user": "anieshbaratam1262@gmail.com",
    "jobs": 115,
    "chars": 19.48
  },
  {
    "user": "rash.kalshetty@gmail.com",
    "jobs": 104,
    "chars": 27.43
  },
  {
    "user": "vishnuv0209@gmail.com",
    "jobs": 95,
    "chars": 34.14
  },
  {
    "user": "shreyachawla1798@gmail.com",
    "jobs": 77,
    "chars": 25.68
  },
  {
    "user": "vijayasrichevugani@gmail.com",
    "jobs": 57,
    "chars": 132.72
  },
  {
    "user": "kamrutha4774@gmail.com",
    "jobs": 53,
    "chars": 32.87
  },
  {
    "user": "aman25barnwal@gmail.com",
    "jobs": 52,
    "chars": 21.71
  },
  {
    "user": "krishna.veni@ozonetel.com",
    "jobs": 33,
    "chars": 22.92
  },
  {
    "user": "amruthavalliyvsr123@gmail.com",
    "jobs": 31,
    "chars": 19.65
  },
  {
    "user": "mohammadtazuddin90@gmail.com",
    "jobs": 28,
    "chars": 11.02
  },
  {
    "user": "padma.balagani@ozonetel.com",
    "jobs": 20,
    "chars": 23.36
  },
  {
    "user": "sudhamay@ozonetel.com",
    "jobs": 18,
    "chars": 61.92
  },
  {
    "user": "biswajit@ozonetel.com",
    "jobs": 18,
    "chars": 49.09
  },
  {
    "user": "rambabu043@gmail.com",
    "jobs": 15,
    "chars": 20.75
  },
  {
    "user": "suryakanthvgangashetty@gmail.com",
    "jobs": 15,
    "chars": 1.55
  },
  {
    "user": "vedavyas.r@ozonetel.com",
    "jobs": 10,
    "chars": 91.27
  },
  {
    "user": "yalla.veera.prakash@gmail.com",
    "jobs": 9,
    "chars": 106.87
  },
  {
    "user": "sairamadabala007@gmail.com",
    "jobs": 8,
    "chars": 29.85
  },
  {
    "user": "pg@fju.us",
    "jobs": 8,
    "chars": 20.72
  },
  {
    "user": "dls2science@gmail.com",
    "jobs": 6,
    "chars": 30.41
  },
  {
    "user": "iit2016082@iiita.ac.in",
    "jobs": 6,
    "chars": 18.63
  },
  {
    "user": "murthyvemuri@msitprogram.net",
    "jobs": 5,
    "chars": 19.24
  },
  {
    "user": "gauravsingh13091990@gmail.com",
    "jobs": 5,
    "chars": 18.55
  },
  {
    "user": "bhavaniu.setty@st.niituniversity.in",
    "jobs": 3,
    "chars": 165.68
  }
 ]
    