export class Job {
    user:String;
    jobs:Number;
    chars:Number;
}