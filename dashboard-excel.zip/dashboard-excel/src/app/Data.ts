
export class Data {
    user:String;
    fragmentID:String;
    assigned_ts:String;
    audio_url: String;
    no_of_chars:Number;
    elapsed_time: Number;
    charspermin:Number;
    deliverable:String;
}

