import { Component } from '@angular/core';
import {USERS} from './userslist';
import {JOBS} from './jobslist';
import { DATES } from './dateslist';
import { Job } from './job';
import { Data } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'dashboard-excel';
  userData=USERS;
  jobsData=JOBS;
  dates=DATES;
  // selectedUser:Data;
  selectedDate: Date;
  selectedJob: Job;

  url;
  audio_deliverable;
  find:boolean = false;
onselectdate(date: Date): void {
  this.selectedDate = date;
  // if(this.selectedDate == this.users.assigned_ts)
  // this.check();
  
}
onselectjob(job: Job): void {
  // this.selectedUser=user;
  // console.log("helooo");
  this.selectedJob = job;
  // this.check();

}

// check():void{
//   console.log(this.userData.length+" "+this.selectedJob.user+" "+this.selectedDate.date);
//   for(let i = 0; i < this.userData.length; i++){
//     if(this.selectedJob.user==this.userData[i].user && this.selectedDate.date==this.userData[i].assigned_ts){
//         this.url = this.userData[i].audio_url;
//         this.audio_deliverable = this.userData[i].deliverable;
//         this.find = true;
//         break;
//         // return true;
//     }
//   }
//   console.log(this.url+" "+this.audio_deliverable+" "+this.find);
  // return false;
// }

}
